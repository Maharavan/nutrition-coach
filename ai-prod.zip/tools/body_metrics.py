from typing import Literal
from pydantic import BaseModel, Field
from strands import tool


class BMIRequest(BaseModel):
    """Model representing a BMI calculation request."""
    weight: float = Field(..., description="Weight of the user in kilograms or pounds")
    height: float = Field(..., description="Height of the user in meters or inches")
    unit: Literal["metric", "imperial"] = Field(..., description="Unit system used: 'metric' or 'imperial'")

class BMIResponse(BaseModel):
    """Model representing a BMI calculation response."""
    bmi: float = Field(..., description="Calculated Body Mass Index (BMI)")
    category: str = Field(..., description="BMI category based on the calculated BMI value")

@tool
def calculate_bmr(request):
    pass

@tool
def bmi_calculator(request: BMIRequest) -> BMIResponse:
    """
    Calculate BMI and determine its category.

    Args:
        weight: Weight in kilograms (metric) or pounds (imperial).
        height: Height in meters (metric) or inches (imperial).
        unit: 'metric' or 'imperial'.

    Returns:
        BMI value and category.
    """
    if request.weight <= 0 or request.height <= 0:
        raise ValueError("Weight and height must be positive values.")
    if request.unit == 'imperial':
        weight = __lbs_to_kg(request.weight)
        height = __inches_to_meters(request.height)
    else:
        weight = request.weight
        height = request.height
    bmi = weight / (height ** 2)
    category = __bmi_category(bmi)
    return BMIResponse(bmi=bmi, category=category)

def __bmi_category(bmi: float) -> str:
    """Determine the BMI category based on the BMI value."""
    match bmi:
        case _ if bmi<18.5:
            return "Underweight"
        case _ if 18.5 <= bmi < 24.9:
            return "Normal weight"
        case _ if 25 <= bmi < 29.9:
            return "Overweight"
        case _ if bmi >= 30:
            return "Obesity"
    
def __lbs_to_kg(pounds: float) -> float:
    """Convert weight from pounds to kilograms."""
    return pounds * 0.453592

def __inches_to_meters(inches: float) -> float:
    """Convert height from inches to meters."""
    return inches * 0.0254

